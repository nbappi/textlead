@extends('sites.layouts.master')

@section('content')
   
    <!-- ======= About Us Section ======= -->
    <section id="about" class="about">
      <div class="container">

        <div class="section-title">
          <h2>Company Value</h2>
          <p>Coming Soon.............</p>
        </div>
      </div>

      </div>
    </section><!-- End About Us Section -->

@endsection