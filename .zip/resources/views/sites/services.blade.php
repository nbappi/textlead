@extends('sites.layouts.master')

@section('content')
   
   <!-- ======= Services Section ======= -->
   <section id="services" class="services">
      <div class="container">

        <div class="section-title">
          <h2>Services</h2>
          <p>Content Coming Soon…</p>
        </div>
      </div>
    </section><!-- End Services Section -->

@endsection