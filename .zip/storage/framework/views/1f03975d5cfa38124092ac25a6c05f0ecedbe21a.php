

<?php $__env->startSection('content'); ?>
   
   <!-- ======= Team Section ======= -->
   <section id="team" class="team section-bg">
      <div class="container">

        <div class="section-title">
          <h2>Our Product Categories</h2>
        </div>

        <div class="row">
          <div class="col-lg-4 col-md-6 d-flex align-items-stretch">
            <div class="member">
              <img src="<?php echo e(asset('public/frontend/assets/img/products/product-1.jpg')); ?>" alt="">
              <div class="social">
                <button type="button" class="btn btn-outline-success">
                    <a href="<?php echo e(route('knit-fabric')); ?>">Knit Fabric</a>
                </button>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch">
            <div class="member">
              <img src="<?php echo e(asset('public/frontend/assets/img/products/product-2.jpg')); ?>" alt="">
              <div class="social">
                <button type="button" class="btn btn-outline-success">
                    <a href="<?php echo e(route('woven-fabric')); ?>">Woven Fabric</a>
                </button>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch">
            <div class="member">
              <img src="<?php echo e(asset('public/frontend/assets/img/products/product-3.jpg')); ?>" alt="">
              <div class="social">
                <button type="button" class="btn btn-outline-success">
                    <a href="<?php echo e(route('propucts')); ?>">Other Fabric</a>
                </button>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Team Section -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('sites.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\texlead\resources\views/sites/products/index.blade.php ENDPATH**/ ?>