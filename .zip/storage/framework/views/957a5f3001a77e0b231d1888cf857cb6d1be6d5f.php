

<?php $__env->startSection('content'); ?>
   
   <!-- ======= Services Section ======= -->
   <section id="services" class="services">
      <div class="container">

        <div class="section-title">
          <h2>Services</h2>
          <p>Content Coming Soon…</p>
        </div>
      </div>
    </section><!-- End Services Section -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('sites.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\texlead\resources\views/sites/services.blade.php ENDPATH**/ ?>