

<?php $__env->startSection('content'); ?>
   
    <!-- ======= About Us Section ======= -->
    <section id="about" class="about">
      <div class="container">

        <div class="section-title">
          <h2>Company profile</h2>
          <p>Coming Soon.............</p>
        </div>

      </div>
    </section><!-- End About Us Section -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('sites.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\texlead\resources\views/sites/about/companyProfile.blade.php ENDPATH**/ ?>