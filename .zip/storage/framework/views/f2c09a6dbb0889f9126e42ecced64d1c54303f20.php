<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title><?php echo $__env->yieldContent('title', 'TEXLEAD ASIA LIMITED'); ?></title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <?php echo $__env->make('sites.layouts.parts.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>

  <?php echo $__env->make('sites.layouts.parts.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <?php echo $__env->make('sites.layouts.parts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if(Request::path() == '/'): ?> 
      <?php echo $__env->make('sites.layouts.parts.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

  

  <main id="main">

    <?php echo $__env->yieldContent('content'); ?>

  </main><!-- End #main -->

  <?php echo $__env->make('sites.layouts.parts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <?php echo $__env->make('sites.layouts.parts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html><?php /**PATH C:\xampp\htdocs\texlead\resources\views/sites/layouts/master.blade.php ENDPATH**/ ?>