 <!-- ======= Footer ======= -->
 <footer id="footer" class="fixed-bottom">
    <div class="container ">
     


      <div class="copyright">
         Copyright <strong><span> &copy; Texlead Asia Limited</span></strong>
      </div>
      <div class="credits">
      
      </div>
    </div>
  </footer><!-- End Footer -->
  


<?php /**PATH C:\xampp\htdocs\texlead\resources\views/sites/layouts/parts/footer.blade.php ENDPATH**/ ?>